import cv2
import numpy as np
from PIL import Image
import os

recognizer = cv2.face_LBPHFaceRecognizer.create()

path = "datasets"


def getImageID(path):
    image_paths = [os.path.join(path, f) for f in os.listdir(path)]
    faces = []
    ids = []
    for image_path in image_paths:
        face_image = Image.open(image_path).convert('L')
        face_np = np.array(face_image)
        id_ = int(os.path.split(image_path)[-1].split(".")[1])
        faces.append(face_np)
        ids.append(id_)
        cv2.imshow("Training", face_np)
        cv2.waitKey(1)
    return ids, faces


IDs, facedata = getImageID(path)
recognizer.train(facedata, np.array(IDs))
recognizer.write("Trainer.yml")
cv2.destroyAllWindows()
print("Training Completed............")